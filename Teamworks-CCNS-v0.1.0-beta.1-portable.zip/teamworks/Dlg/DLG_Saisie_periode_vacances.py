#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
#-----------------------------------------------------------
# Auteur:        Ivan LUCAS
# Copyright:    (c) 2008-09 Ivan LUCAS
# Licence:      Licence GNU GPL
#-----------------------------------------------------------

import Chemins
from Utils.UTILS_Traduction import _
import wx
from Ctrl import CTRL_Bouton_image
import GestionDB
import datetime
import FonctionsPerso
if 'phoenix' in wx.PlatformInfo:
    from wx.adv import DatePickerCtrl, DP_DROPDOWN
else :
    from wx import DatePickerCtrl, DP_DROPDOWN


class Dialog(wx.Dialog):
    def __init__(self, parent, title="" , IDperiode=0):
        wx.Dialog.__init__(self, parent, -1, style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.MAXIMIZE_BOX|wx.MINIMIZE_BOX)
        self.parent = parent
        self.panel_base = wx.Panel(self, -1)
        
        self.sizer_periode_staticbox = wx.StaticBox(self.panel_base, -1, _(u"Nom de la p�riode"))
        choices = [_(u"F�vrier"), _(u"P�ques"), _(u"Et�"), _(u"Toussaint"), _(u"No�l")]
        self.label_nom = wx.StaticText(self.panel_base, -1, _(u"Nom :"))
        self.choice_nom = wx.Choice(self.panel_base, -1, choices=choices, size=(100, -1))
        self.label_annee = wx.StaticText(self.panel_base, -1, _(u"Ann�e :"))
        self.text_annee = wx.TextCtrl(self.panel_base, -1, "", style=wx.TE_CENTRE, size=(50, -1))
        
        self.sizer_dates_staticbox = wx.StaticBox(self.panel_base, -1, _(u"Dates de la p�riode"))
        self.label_dateDebut = wx.StaticText(self.panel_base, -1, u"Du")
        self.datepicker_dateDebut = DatePickerCtrl(self.panel_base, -1, style=DP_DROPDOWN)
        self.label_dateFin = wx.StaticText(self.panel_base, -1, _(u"au"))
        self.datepicker_dateFin = DatePickerCtrl(self.panel_base, -1, style=DP_DROPDOWN)
        
        self.bouton_aide = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Aide"), cheminImage=Chemins.GetStaticPath("Images/32x32/Aide.png"))
        self.bouton_ok = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Ok"), cheminImage=Chemins.GetStaticPath("Images/32x32/Valider.png"))
        self.bouton_annuler = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Annuler"), cheminImage=Chemins.GetStaticPath("Images/32x32/Annuler.png"))
        
        self.IDperiode = IDperiode
        if IDperiode != 0 : 
            self.Importation()

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.OnBoutonAide, self.bouton_aide)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonOk, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonAnnuler, self.bouton_annuler)

    def __set_properties(self):
        self.SetTitle(_(u"Gestion des p�riodes de vacances"))
        if 'phoenix' in wx.PlatformInfo:
            _icon = wx.Icon()
        else :
            _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Logo.png"), wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.choice_nom.SetToolTip(wx.ToolTip(_(u"Choisissez ici le nom de la p�riode")))
        self.text_annee.SetToolTip(wx.ToolTip(_(u"Saisissez ici l'ann�e de la p�riode. Ex. : '2008'")))
        self.datepicker_dateDebut.SetToolTip(wx.ToolTip(_(u"Saisissez ici la date de d�but de la p�riode")))
        self.datepicker_dateFin.SetToolTip(wx.ToolTip(_(u"Saisissez ici la date de fin de la p�riode")))
        self.bouton_aide.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour obtenir de l'aide")))
        self.bouton_aide.SetSize(self.bouton_aide.GetBestSize())
        self.bouton_ok.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour valider")))
        self.bouton_ok.SetSize(self.bouton_ok.GetBestSize())
        self.bouton_annuler.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour annuler la saisie")))
        self.bouton_annuler.SetSize(self.bouton_annuler.GetBestSize())

    def __do_layout(self):
        sizer_base = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_base = wx.FlexGridSizer(rows=3, cols=1, vgap=10, hgap=10)
        grid_sizer_boutons = wx.FlexGridSizer(rows=1, cols=4, vgap=10, hgap=10)
        
        sizer_contenu_1 = wx.StaticBoxSizer(self.sizer_periode_staticbox, wx.VERTICAL)
        grid_sizer_contenu_1 = wx.FlexGridSizer(rows=1, cols=6, vgap=10, hgap=10)
        grid_sizer_contenu_1.Add(self.label_nom, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_contenu_1.Add(self.choice_nom, 0, 0, 0)
        grid_sizer_contenu_1.Add(self.label_annee, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_contenu_1.Add(self.text_annee, 0, 0, 0)
        sizer_contenu_1.Add(grid_sizer_contenu_1, 1, wx.ALL|wx.EXPAND, 10)
        
        sizer_contenu_2 = wx.StaticBoxSizer(self.sizer_dates_staticbox, wx.VERTICAL)
        grid_sizer_contenu_2 = wx.FlexGridSizer(rows=1, cols=6, vgap=10, hgap=10)
        grid_sizer_contenu_2.Add(self.label_dateDebut, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_contenu_2.Add(self.datepicker_dateDebut, 0, 0, 0)
        grid_sizer_contenu_2.Add(self.label_dateFin, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_contenu_2.Add(self.datepicker_dateFin, 0, 0, 0)
        sizer_contenu_2.Add(grid_sizer_contenu_2, 1, wx.ALL|wx.EXPAND, 10)
        
        grid_sizer_base.Add(sizer_contenu_1, 1, wx.TOP|wx.LEFT|wx.RIGHT|wx.EXPAND, 10)
        grid_sizer_base.Add(sizer_contenu_2, 1, wx.BOTTOM|wx.LEFT|wx.RIGHT|wx.EXPAND, 10)
        
        grid_sizer_boutons.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_boutons.Add((20, 20), 0, wx.EXPAND, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_annuler, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 10)
        self.panel_base.SetSizer(grid_sizer_base)
        sizer_base.Add(self.panel_base, 1, wx.EXPAND, 0)
        self.SetSizer(sizer_base)
        sizer_base.Fit(self)
        self.Layout()
        self.CenterOnScreen()

    def Importation(self):
        DB = GestionDB.DB()
        req = "SELECT * FROM periodes_vacances WHERE IDperiode=%d" % self.IDperiode
        DB.ExecuterReq(req)
        donnees = DB.ResultatReq()[0]
        DB.Close()
        if len(donnees) == 0: return
        # Place la valeur dans le controle nom p�riode
        self.SelectChoice(self.choice_nom, donnees[1])
        # Place la valeur dans le controle annee
        self.text_annee.SetValue(str(donnees[2]))
        # Place la date de d�but dans le cdatePicker 
        jour = int(donnees[3][8:10])
        mois = int(donnees[3][5:7])-1
        annee = int(donnees[3][:4])
        date = wx.DateTime()
        date.Set(jour, mois, annee)
        self.datepicker_dateDebut.SetValue(date)
        # Place la date de fin dans le cdatePicker 
        jour = int(donnees[4][8:10])
        mois = int(donnees[4][5:7])-1
        annee = int(donnees[4][:4])
        date = wx.DateTime()
        date.Set(jour, mois, annee)
        self.datepicker_dateFin.SetValue(date)

    def SelectChoice(self, controle, data):
        nbreItems = controle.GetCount()
        index = 0
        for item in range(nbreItems) :
            if controle.GetString(index) == data :
                controle.SetSelection(index)
                return
            index += 1

    def GetChoiceValue(self, controle):
        selection = controle.GetSelection()
        if selection != -1 : 
            IDselection = controle.GetString(selection)
        else:
            IDselection = None
        return IDselection
    
    def Sauvegarde(self):
        """ Sauvegarde des donn�es dans la base de donn�es """
        
        # R�cup�ration ds valeurs saisies
        varNom = self.GetChoiceValue(self.choice_nom)
        varAnnee = self.text_annee.GetValue()
        varDateDebut = self.datepicker_dateDebut.GetValue()
        varTxtDateDebut = str(datetime.date(varDateDebut.GetYear(), varDateDebut.GetMonth()+1, varDateDebut.GetDay()))
        varDateFin = self.datepicker_dateFin.GetValue()
        varTxtDateFin = str(datetime.date(varDateFin.GetYear(), varDateFin.GetMonth()+1, varDateFin.GetDay()))
        
        DB = GestionDB.DB()
        # Cr�ation de la liste des donn�es
        listeDonnees = [    ("nom",   varNom),  
                                    ("annee",    varAnnee), 
                                    ("date_debut",    varTxtDateDebut), 
                                    ("date_fin",    varTxtDateFin), ]
        if self.IDperiode == 0:
            # Enregistrement d'une nouvelle valeur
            newID = DB.ReqInsert("periodes_vacances", listeDonnees)
            ID = newID
        else:
            # Modification des valeurs
            DB.ReqMAJ("periodes_vacances", listeDonnees, "IDperiode", self.IDperiode)
            ID = self.IDperiode
        DB.Commit()
        DB.Close()
        return ID

    def OnBoutonAide(self, event):
        from Utils import UTILS_Aide
        UTILS_Aide.Aide("Lespriodesdevacances")

    def OnBoutonAnnuler(self, event):
        self.EndModal(wx.ID_CANCEL)

    def OnBoutonOk(self, event):
        """ Validation des donn�es saisies """

        # V�rifie que des valeurs ont �t� saisies
        valeur = self.GetChoiceValue(self.choice_nom)
        if valeur == None :
            dlg = wx.MessageDialog(self, _(u"Vous devez s�lectionner un nom de p�riode dans la liste propos�e !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            self.choice_nom.SetFocus()
            return

        valeur = self.text_annee.GetValue()
        if valeur == "" :
            dlg = wx.MessageDialog(self, _(u"Vous devez saisir une ann�e valide."), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            self.text_annee.SetFocus()
            return
        # V�rifie que la valeur est bien constitu�e de chiffres uniquement
        incoherences = ""
        for lettre in valeur :
            if lettre not in "0123456789." : incoherences += "'"+ lettre + "', "
        if len(incoherences) != 0 :
            dlg = wx.MessageDialog(self, _(u"L'ann�e que vous avez saisie n'est pas correcte."), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            self.text_annee.SetFocus()
            return
        valeur = int(valeur)
        if valeur < 1000 or valeur > 3000 :
            dlg = wx.MessageDialog(self, _(u"L'ann�e que vous avez saisie n'est pas correcte."), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            self.text_annee.SetFocus()
            return
        
        date_debut = self.datepicker_dateDebut.GetValue() # self.GetDatePickerValue(self.datepicker_date_debut)
        date_fin = self.datepicker_dateFin.GetValue() # self.GetDatePickerValue(self.datepicker_date_fin)
        # V�rifie que la date de fin est sup�rieure � la date de d�but de contrat
        if date_debut > date_fin :
            dlg = wx.MessageDialog(self, _(u"La date de fin de vacances doit �tre sup�rieure � la date de d�but !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            self.datepicker_dateFin.SetFocus()
            return
        
        # Sauvegarde
        self.Sauvegarde()
        # MAJ du listCtrl des valeurs de points
        if FonctionsPerso.FrameOuverte("panel_config_periodes_vacs") != None :
            self.GetParent().MAJ_ListCtrl()
            
        # Fermeture
        self.EndModal(wx.ID_OK)

    
    
if __name__ == "__main__":
    app = wx.App(0)
    dlg = Dialog(None, "", IDperiode=1)
    dlg.ShowModal()
    dlg.Destroy()
    app.MainLoop()
