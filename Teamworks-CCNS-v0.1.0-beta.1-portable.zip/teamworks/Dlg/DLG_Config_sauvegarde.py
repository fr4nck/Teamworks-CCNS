#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
#-----------------------------------------------------------
# Auteur:        Ivan LUCAS
# Copyright:    (c) 2008-09 Ivan LUCAS
# Licence:      Licence GNU GPL
#-----------------------------------------------------------

import Chemins
from Utils.UTILS_Traduction import _
import wx
from Ctrl import CTRL_Bouton_image
import GestionDB
import FonctionsPerso
import os
import zipfile
import wx.lib.agw.customtreectrl as CT
import datetime
from Utils import UTILS_Fichiers
from Ol import OL_Sauvegardes_auto



LISTE_SOURCES = [
    [_(u"Les fichiers de donn�es"), UTILS_Fichiers.GetRepData(), "DATA"],
    [_(u"Les contrats �dit�s"), UTILS_Fichiers.GetRepEditions(), "CONE"],
    [_(u"Les mod�les de contrats"), UTILS_Fichiers.GetRepModeles(), "CONM"],
    [_(u"Les photos des personnes"), "Photos/", "PHOT"],
    ] # Type Source, r�pertoire, code extension
                                    
LISTE_INDESIRABLES = [
            "Thumbs.db",
            "Exemple.twk",
            "Contrat d'engagement �ducatif - Exemple.doc",
            "Contrat d'engagement �ducatif - Exemple.odt",
            "Contrat � dur�e d�termin�e - Exemple.doc",
            "Contrat � dur�e d�termin�e - Exemple.odt",
            "Autorisation parentale mineurs - Exemple.doc",
            "Autorisation parentale mineurs - Exemple.odt",
            "Certificat de travail - Exemple.doc",
            "Certificat de travail - Exemple.odt",
            "Contrat � dur�e d�termin�e - Exemple.doc",
            "Contrat � dur�e d�termin�e - Exemple.odt",
            "Contrat d'engagement �ducatif - Exemple.doc",
            "Contrat d'engagement �ducatif - Exemple.odt",
            "Fiche candidature animateur - Exemple.doc",
            "Fiche candidature animateur - Exemple.odt",
            "Fiche renseignements salari� - Exemple.doc",
            "Fiche renseignements salari� - Exemple.odt",
            "Invitation r�union - Exemple.doc",
            "Invitation r�union - Exemple.odt",
            "20090529142759BMW1.jpg",
            "20090529142759BMW2.jpg",
            "20090529142759BMW3.jpg",
            "20090529142759BMW4.jpg",
            "20090529142759BMW5.jpg",
            "20090529142759BMW6.jpg",
            "20090529142759BMW7.jpg",
            "20090529142759BMW8.jpg",
            "20090529142759BMW9.jpg",
            "20090529142759BMW10.jpg",
            "20090529142759BMW11.jpg",
            "20090529142759BMW12.jpg",
            "20090529142759BMW13.jpg",
            "20090529142759BMW14.jpg",
            "20090529142759BMW15.jpg",
            "20090529142759BMW16.jpg",
            "20090529142759BMW17.jpg",
            ]


class Panel(wx.Panel):
    def __init__(self, parent, ID=-1):
        wx.Panel.__init__(self, parent, ID, name="panel_config_sauvegarde", style=wx.TAB_TRAVERSAL)

        self.barreTitre = FonctionsPerso.BarreTitre(self, _(u"Sauvegarde automatique"), u"")
        texteIntro = _(u"Vous pouvez programmer ici des sauvegardes automatiques de vos donn�es.")
        self.label_introduction = FonctionsPerso.StaticWrapText(self, -1, texteIntro)

        # Cadre d'activation
        self.staticbox1 = wx.StaticBox(self, -1, _(u"Proc�dures de sauvegarde automatique"))

        self.ctrl_listview = OL_Sauvegardes_auto.ListView(self, id=-1, style=wx.LC_REPORT|wx.SUNKEN_BORDER|wx.LC_SINGLE_SEL|wx.LC_HRULES|wx.LC_VRULES)
        self.ctrl_listview.MAJ()
        self.ctrl_recherche = OL_Sauvegardes_auto.CTRL_Outils(self, listview=self.ctrl_listview)

        self.bouton_ajouter = wx.BitmapButton(self, -1, wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Ajouter.png"), wx.BITMAP_TYPE_ANY))
        self.bouton_modifier = wx.BitmapButton(self, -1, wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Modifier.png"), wx.BITMAP_TYPE_ANY))
        self.bouton_supprimer = wx.BitmapButton(self, -1, wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Supprimer.png"), wx.BITMAP_TYPE_ANY))
        self.bouton_aide = wx.BitmapButton(self, -1, wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Aide.png"), wx.BITMAP_TYPE_ANY))

        # Binds
        self.Bind(wx.EVT_BUTTON, self.ctrl_listview.Ajouter, self.bouton_ajouter)
        self.Bind(wx.EVT_BUTTON, self.ctrl_listview.Modifier, self.bouton_modifier)
        self.Bind(wx.EVT_BUTTON, self.ctrl_listview.Supprimer, self.bouton_supprimer)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonAide, self.bouton_aide)

        # Propri�t�s
        self.bouton_ajouter.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour ajouter une proc�dure de sauvegarde")))
        self.bouton_modifier.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour modifier la proc�dure de sauvegarde s�lectionn�e dans la liste")))
        self.bouton_supprimer.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour supprimer la proc�dure de sauvegarde s�lectionn�e dans la liste")))
        self.bouton_aide.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour obtenir de l'aide")))

        if parent.GetName() != "treebook_configuration":
            self.bouton_aide.Show(False)

        # Layout
        grid_sizer_principal = wx.FlexGridSizer(rows=8, cols=1, vgap=0, hgap=0)
        grid_sizer_principal.Add(self.barreTitre, 1, wx.EXPAND, 0)
        grid_sizer_principal.Add(self.label_introduction, 1, wx.ALL | wx.EXPAND, 10)

        # Cadre 1
        staticbox1 = wx.StaticBoxSizer(self.staticbox1, wx.VERTICAL)
        grid_sizer_principal.Add(staticbox1, 1, wx.ALL | wx.EXPAND, 10)

        grid_sizer_contenu = wx.FlexGridSizer(rows=2, cols=2, vgap=5, hgap=5)

        grid_sizer_contenu.Add(self.ctrl_listview, 0, wx.EXPAND, 0)

        grid_sizer_droit = wx.FlexGridSizer(rows=5, cols=1, vgap=5, hgap=5)
        grid_sizer_droit.Add(self.bouton_ajouter, 0, 0, 0)
        grid_sizer_droit.Add(self.bouton_modifier, 0, 0, 0)
        grid_sizer_droit.Add(self.bouton_supprimer, 0, 0, 0)
        grid_sizer_droit.Add((5, 5), 0, wx.EXPAND, 0)
        grid_sizer_droit.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_droit.AddGrowableRow(3)

        grid_sizer_contenu.Add(grid_sizer_droit, 1, wx.EXPAND, 0)

        grid_sizer_contenu.Add(self.ctrl_recherche, 0, wx.EXPAND, 0)

        grid_sizer_contenu.AddGrowableRow(0)
        grid_sizer_contenu.AddGrowableCol(0)

        staticbox1.Add(grid_sizer_contenu, 1, wx.EXPAND | wx.ALL, 10)

        grid_sizer_principal.AddGrowableRow(2)
        grid_sizer_principal.AddGrowableCol(0)

        self.SetSizer(grid_sizer_principal)
        grid_sizer_principal.Fit(self)

    def MAJpanel(self):
        pass

    def OnBoutonAide(self, event):
        from Utils import UTILS_Aide
        UTILS_Aide.Aide("Lasauvegardeautomatique")













# ------------------------------------------------------------------------------

def GetListeSourcesStr():
    txt = ""
    for source in LISTE_SOURCES :
        txt += source[2] + ";"
    return txt[:-1]


class Sauvegarde():
    """ Creation d'un sauvegarde occasionnelle ou automatique """
    def Save(self, fichierDest="", listeFichiers=[]) :
        """ listeFichiers = [ (extension, rep, nomFichier), ] """
        if len(listeFichiers) == 0 : return "Rien � sauvegarder !"
                
        try :                                   
            # Cr�ation du fichier ZIP
            fichierZip = zipfile.ZipFile(fichierDest, "w", compression=zipfile.ZIP_DEFLATED)

            # Int�gration des fichiers dans le ZIP
            for extension, rep, nomFichier in listeFichiers :
                cheminFichier = rep + nomFichier
                nouveauNomFichier = extension + "_" + nomFichier
                fichierZip.write(cheminFichier, nouveauNomFichier )
                
            # Finalise le fichier ZIP
            fichierZip.close()
            
            return None

        except :
            return "Erreur inconnue"





class MyFrame(wx.Frame):
    def __init__(self, parent, title="" ):
        wx.Frame.__init__(self, parent, -1, title=title, name="frm_config_sauvegarde", style=wx.DEFAULT_FRAME_STYLE)
        self.parent = parent

        self.panel_base = wx.Panel(self, -1)
        self.panel_contenu = Panel(self.panel_base)
        self.panel_contenu.barreTitre.Show(False)
        self.bouton_aide = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Aide"), cheminImage=Chemins.GetStaticPath("Images/32x32/Aide.png"))
        self.bouton_ok = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Ok"), cheminImage=Chemins.GetStaticPath("Images/32x32/Valider.png"))
        self.bouton_annuler = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Annuler"), cheminImage=Chemins.GetStaticPath("Images/32x32/Annuler.png"))
        self.__set_properties()
        self.__do_layout()
        
        self.Bind(wx.EVT_BUTTON, self.Onbouton_aide, self.bouton_aide)
        self.Bind(wx.EVT_BUTTON, self.Onbouton_ok, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.Onbouton_annuler, self.bouton_annuler)
        self.Bind(wx.EVT_CLOSE, self.OnClose)
        
        self.SetMinSize((550, 450))
        self.SetSize((550, 450))

    def __set_properties(self):
        self.SetTitle(_(u"Sauvegarde automatique"))
        if 'phoenix' in wx.PlatformInfo:
            _icon = wx.Icon()
        else :
            _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Logo.png"), wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.bouton_aide.SetToolTip(wx.ToolTip("Cliquez ici pour obtenir de l'aide"))
        self.bouton_aide.SetSize(self.bouton_aide.GetBestSize())
        self.bouton_ok.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour valider")))
        self.bouton_ok.SetSize(self.bouton_ok.GetBestSize())
        self.bouton_annuler.SetToolTip(wx.ToolTip(_(u"Cliquez pour annuler et fermer")))
        self.bouton_annuler.SetSize(self.bouton_annuler.GetBestSize())
        

    def __do_layout(self):
        sizer_base = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_base = wx.FlexGridSizer(rows=3, cols=1, vgap=0, hgap=0)
        grid_sizer_boutons = wx.FlexGridSizer(rows=1, cols=6, vgap=10, hgap=10)
        sizer_pages = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_base.Add(sizer_pages, 1, wx.ALL|wx.EXPAND, 0)
        sizer_pages.Add(self.panel_contenu, 1, wx.EXPAND | wx.TOP, 10)
        grid_sizer_boutons.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_boutons.Add((20, 20), 0, wx.EXPAND, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_annuler, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT|wx.BOTTOM|wx.RIGHT|wx.EXPAND, 10)
        self.panel_base.SetSizer(grid_sizer_base)
        grid_sizer_base.AddGrowableRow(0)
        grid_sizer_base.AddGrowableCol(0)
        sizer_base.Add(self.panel_base, 1, wx.EXPAND, 0)
        self.SetSizer(sizer_base)
        self.Layout()
        self.Centre()
        self.sizer_pages = sizer_pages


        
        
    def OnClose(self, event):
        event.Skip()
        
    def Onbouton_aide(self, event):
        from Utils import UTILS_Aide
        UTILS_Aide.Aide("Lasauvegardeautomatique")
            
    def Onbouton_annuler(self, event):
        # Si frame Creation_contrats ouverte, on met � jour le listCtrl Valeurs de points
        self.MAJparents()
        # Fermeture
        self.Destroy()
        
    def Onbouton_ok(self, event):
        # Si frame Creation_contrats ouverte, on met � jour le listCtrl Valeurs de points
        self.MAJparents()
        # Fermeture
        self.Destroy()
        
    def MAJparents(self):
        if FonctionsPerso.FrameOuverte("frm_creation_contrats") != None :
            self.GetParent().MAJ_ListCtrl()
        if FonctionsPerso.FrameOuverte("frm_creation_modele_contrats") != None :
            self.GetParent().MAJ_ListCtrl() 




# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class Saisie_sauvegarde_auto(wx.Frame):
    def __init__(self, parent, title=""):
        wx.Frame.__init__(self, parent, -1, title=title, style=wx.DEFAULT_FRAME_STYLE)
        self.panel_base = wx.Panel(self, -1)
        self.staticbox = wx.StaticBox(self.panel_base, -1, _(u"Param�tres"))
        self.label_frequence = wx.StaticText(self.panel_base, -1, _(u"Fr�quence :"))
        listeFrequences = [ _(u"A chaque fermeture du logiciel"), _(u"Toutes les semaines"), _(u"Tous les quinze jours"), _(u"Tous les mois")]
        self.choice_frequence = wx.Choice(self.panel_base, -1, size=(300, -1), choices = listeFrequences)
        listeElements = []
        for source in LISTE_SOURCES :
            listeElements.append(source[0])
        self.label_elements = wx.StaticText(self.panel_base, -1, _(u"El�ments � sauver :"))
        self.listBox_elements = wx.CheckListBox(self.panel_base, -1, (-1, -1), wx.DefaultSize, listeElements)
        self.label_destination = wx.StaticText(self.panel_base, -1, _(u"Destination :"))
        self.textctrl_destination = wx.TextCtrl(self.panel_base, -1, "", size=(-1, -1))
        self.bouton_destination = wx.BitmapButton(self.panel_base, -1, wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Repertoire.png"), wx.BITMAP_TYPE_ANY))
        self.label_conservation = wx.StaticText(self.panel_base, -1, _(u"Conservation :"))
        self.choice_conservation = wx.Choice(self.panel_base, -1, choices = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"])
        self.label_destination2 = wx.StaticText(self.panel_base, -1, _(u"sauvegardes de s�curit� seront conserv�es en archive."))
        
        self.bouton_aide = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Aide"), cheminImage=Chemins.GetStaticPath("Images/32x32/Aide.png"))
        self.bouton_ok = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Ok"), cheminImage=Chemins.GetStaticPath("Images/32x32/Valider.png"))
        self.bouton_annuler = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Annuler"), cheminImage=Chemins.GetStaticPath("Images/32x32/Annuler.png"))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.OnBoutonAide, self.bouton_aide)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonOk, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonAnnuler, self.bouton_annuler)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonDestination, self.bouton_destination)
        self.Bind(wx.EVT_CLOSE, self.OnClose)
        
        self.Importation()

        
    def __set_properties(self):
        if 'phoenix' in wx.PlatformInfo:
            _icon = wx.Icon()
        else :
            _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Sauvegarder_param.png"), wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetTitle(_(u"Param�tres de la sauvegarde automatique"))
        self.bouton_aide.SetToolTip(wx.ToolTip("Cliquez ici pour obtenir de l'aide"))
        self.bouton_aide.SetSize(self.bouton_aide.GetBestSize())
        self.bouton_ok.SetToolTip(wx.ToolTip("Cliquez ici pour valider"))
        self.bouton_ok.SetSize(self.bouton_ok.GetBestSize())
        self.bouton_annuler.SetToolTip(wx.ToolTip("Cliquez ici pour annuler la saisie"))
        self.bouton_annuler.SetSize(self.bouton_annuler.GetBestSize())

    def __do_layout(self):
        sizer_base = wx.BoxSizer(wx.VERTICAL)
        sizer_base_2 = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_base = wx.FlexGridSizer(rows=2, cols=1, vgap=0, hgap=0)
        grid_sizer_boutons = wx.FlexGridSizer(rows=1, cols=4, vgap=10, hgap=10)
        
        # Cadre
        staticbox = wx.StaticBoxSizer(self.staticbox, wx.VERTICAL)
        grid_sizer_param = wx.FlexGridSizer(rows=4, cols=2, vgap=10, hgap=10)
        grid_sizer_param.Add(self.label_frequence, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_param.Add(self.choice_frequence, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_param.Add(self.label_elements, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_param.Add(self.listBox_elements, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_param.Add(self.label_destination, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        
        grid_sizer_destination = wx.FlexGridSizer(rows=1, cols=2, vgap=10, hgap=10)
        grid_sizer_destination.Add(self.textctrl_destination, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_destination.Add(self.bouton_destination, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_destination.AddGrowableCol(0)
        grid_sizer_param.Add(grid_sizer_destination, 1, wx.EXPAND|wx.ALL, 0)
        
        grid_sizer_conservation = wx.FlexGridSizer(rows=1, cols=2, vgap=10, hgap=10)
        grid_sizer_conservation.Add(self.choice_conservation, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_conservation.Add(self.label_destination2, 0, wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL, 0)
        
        grid_sizer_param.Add(self.label_conservation, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_param.Add(grid_sizer_conservation, 0, wx.ALL|wx.EXPAND, 0)
        staticbox.Add(grid_sizer_param, 1, wx.EXPAND|wx.ALL, 10)
        grid_sizer_base.Add(staticbox, 1, wx.ALL|wx.EXPAND, 10)
        
        grid_sizer_boutons.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_boutons.Add((20, 20), 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_annuler, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 10)
        
        sizer_base_2.Add(grid_sizer_base, 1, wx.EXPAND, 0)
        self.panel_base.SetSizer(sizer_base_2)
        sizer_base.Add(self.panel_base, 1, wx.EXPAND, 0)
        self.SetSizer(sizer_base)        
        sizer_base.Fit(self)
        self.Layout()
        self.CentreOnScreen()
 
    def Importation(self):
        """ Recherche dans la base des param�tres de la sauvegarde auto. """
        DB = GestionDB.DB()        
        req = "SELECT save_active, save_frequence, save_elements, save_destination, save_conservation FROM divers WHERE IDdivers=1;"
        DB.ExecuterReq(req)
        donnees = DB.ResultatReq()
        DB.Close()
        if len(donnees) == 0 : return
        self.frequence = donnees[0][1]
        self.elements = donnees[0][2]
        self.destination = donnees[0][3]
        self.conservation = donnees[0][4]
        
        # Remplissage choice frequence
        if type(self.frequence) == int :
            self.choice_frequence.Select(self.frequence)
        # Remplissage listBox Elements
        if self.elements != "" and self.elements != None :
            self.listeElements = self.elements.split(";")
            index = 0
            for source in LISTE_SOURCES :
                if source[2] in self.listeElements :
                    self.listBox_elements.Check(index, True)
                else:
                    self.listBox_elements.Check(index, False)
                index += 1
        # Remplissage texte Destination
        self.textctrl_destination.SetValue(self.destination)
        # Remplissage
        if type(self.conservation) == int :
            self.choice_conservation.Select(self.conservation)

    def OnBoutonDestination(self, event):
        if self.textctrl_destination.GetValue != "" : 
            cheminDefaut = self.textctrl_destination.GetValue()
            if os.path.isdir(cheminDefaut) == False :
                cheminDefaut = ""
        else:
            cheminDefaut = ""
        dlg = wx.DirDialog(self, _(u"Veuillez s�lectionner un r�pertoire de destination :"), defaultPath=cheminDefaut, style=wx.DD_DEFAULT_STYLE | wx.DD_DIR_MUST_EXIST)
        if dlg.ShowModal() == wx.ID_OK:
            self.textctrl_destination.SetValue(dlg.GetPath())
        dlg.Destroy()
        
        
    def OnClose(self, event):
        event.Skip()
        
    def OnBoutonAide(self, event):
        from Utils import UTILS_Aide
        UTILS_Aide.Aide("Lasauvegardeautomatique")

    def OnBoutonAnnuler(self, event):
        self.Destroy()

    def OnBoutonOk(self, event):
        """ Validation des donn�es saisies """
        
        # Fr�quence
        varFrequence = self.choice_frequence.GetSelection()
        
        # liste des �l�ments � sauver
        varElements = ""
        for index in range(self.listBox_elements.GetCount()) :
            if self.listBox_elements.IsChecked(index) == True :
                varElements += LISTE_SOURCES[index][2] + ";"
        if len(varElements)>0 :
            varElements = varElements[:-1]
        else:
            dlg = wx.MessageDialog(self, _(u"Vous devez s�lectionner au moins un �l�ment � sauvegarder dans la liste propos�e !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
            
        # Destination
        varDestination = self.textctrl_destination.GetValue()
        if varDestination == "" :
            dlg = wx.MessageDialog(self, _(u"Vous devez s�lectionner un r�pertoire de destination valide !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # Teste la validit� du r�pertoire
        if os.path.isdir(varDestination) == False :
            dlg = wx.MessageDialog(self, _(u"Le r�pertoire de destination s�lectionn� ne semble pas valide. Veuillez v�rifier votre saisie !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # Conservation
        varConservation = self.choice_conservation.GetSelection()
           
    
        # Sauvegarde
                # Enregistrement dans la base
        DB = GestionDB.DB()
        listeDonnees = [    ("save_frequence",   varFrequence),
                                    ("save_elements",   varElements),
                                    ("save_destination",   varDestination),
                                    ("save_conservation",   varConservation),]
        DB.ReqMAJ("divers", listeDonnees, "IDdivers", 1)
        DB.Commit()
        DB.Close()
        
        # MAJ du panel Password
        if FonctionsPerso.FrameOuverte("panel_config_sauvegarde") != None :
            self.GetParent().MAJpanel()

        # Fermeture
        self.Destroy()
        

# ------------------------------------------------------------------------------------------------------------------------------------------------------------




class Saisie_sauvegarde_occasionnelle(wx.Frame):
    def __init__(self, parent, title=""):
        wx.Frame.__init__(self, parent, -1, title=title, style=wx.DEFAULT_FRAME_STYLE)
        self.panel_base = wx.Panel(self, -1)
        texteIntro = _(u"Vous pouvez ici cr�er une sauvegarde occasionnelle de vos donn�es. Cela peut vous �tre utile si vous souhaitez par exemple sauvegarder certaines donn�es sur une cl� USB ou si vous allez changer d'ordinateur. Dans ce dernier cas, il vous suffira ensuite de restaurer la sauvegarde sur votre nouvel ordinateur...")
        self.label_introduction = FonctionsPerso.StaticWrapText(self.panel_base, -1, texteIntro)
        self.staticbox = wx.StaticBox(self.panel_base, -1, _(u"Param�tres de la sauvegarde"))
        
        self.label_nomFichier = wx.StaticText(self.panel_base, -1, _(u"Nom sauvegarde :"))
        self.textctrl_nomFichier = wx.TextCtrl(self.panel_base, -1, "")

        self.label_elements = wx.StaticText(self.panel_base, -1, _(u"El�ments � sauver :"))
        self.treeCtrl = TreeCtrl_Sauvegarde(self.panel_base, -1)       
        
        self.label_destination = wx.StaticText(self.panel_base, -1, _(u"Destination :"))
        standardPath = wx.StandardPaths.Get()
        destination = standardPath.GetDocumentsDir()
        self.textctrl_destination = wx.TextCtrl(self.panel_base, -1, destination, size=(-1, -1))
        self.bouton_destination = wx.BitmapButton(self.panel_base, -1, wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Repertoire.png"), wx.BITMAP_TYPE_ANY))
        
        self.bouton_aide = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Aide"), cheminImage=Chemins.GetStaticPath("Images/32x32/Aide.png"))
        self.bouton_ok = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Ok"), cheminImage=Chemins.GetStaticPath("Images/32x32/Valider.png"))
        self.bouton_annuler = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Annuler"), cheminImage=Chemins.GetStaticPath("Images/32x32/Annuler.png"))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.OnBoutonAide, self.bouton_aide)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonOk, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonAnnuler, self.bouton_annuler)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonDestination, self.bouton_destination)
        self.Bind(wx.EVT_CLOSE, self.OnClose)
        
        # Cr��e le nom de Fichier ZIP par d�faut
        #date_jour =  str(datetime.date.today().day) + "-" + str(datetime.date.today().month) + "-" + str(datetime.date.today().year)
        date_jour =  str(datetime.date.today())
        self.textctrl_nomFichier.SetValue("Sauvegarde_" + date_jour)

        
    def __set_properties(self):
        if 'phoenix' in wx.PlatformInfo:
            _icon = wx.Icon()
        else :
            _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Sauvegarder.png"), wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetTitle(_(u"Param�tres de la sauvegarde occasionnelle"))
        self.textctrl_nomFichier.SetToolTip(wx.ToolTip(_(u"Saisissez ici un nom pour votre fichier de sauvegarde \nou laissez celui donn� par d�faut")))
        #self.treeCtrl.SetToolTip(wx.ToolTip(_(u"Cochez les �l�ments que vous souhaitez sauvegarder")))
        self.textctrl_destination.SetToolTip(wx.ToolTip(_(u"Vous pouvez saisir ici le r�pertoire de destination pour votre fichier de sauvegarde \nou cliquez sur le bouton pour choisir un emplacement")))
        self.bouton_destination.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour s�lectionner un r�pertoire de destination")))
        self.bouton_aide.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour obtenir de l'aide")))
        self.bouton_aide.SetSize(self.bouton_aide.GetBestSize())
        self.bouton_ok.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour valider")))
        self.bouton_ok.SetSize(self.bouton_ok.GetBestSize())
        self.bouton_annuler.SetToolTip(wx.ToolTip(_(u"Cliquez ici pour annuler la saisie")))
        self.bouton_annuler.SetSize(self.bouton_annuler.GetBestSize())

    def __do_layout(self):
        sizer_base = wx.BoxSizer(wx.VERTICAL)
        sizer_base_2 = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_base = wx.FlexGridSizer(rows=2, cols=1, vgap=0, hgap=0)
        grid_sizer_boutons = wx.FlexGridSizer(rows=1, cols=4, vgap=10, hgap=10)
        grid_sizer_base.Add(self.label_introduction, 1, wx.ALL|wx.EXPAND, 10)
        
        # Cadre
        staticbox = wx.StaticBoxSizer(self.staticbox, wx.VERTICAL)
        grid_sizer_param = wx.FlexGridSizer(rows=5, cols=2, vgap=10, hgap=10)
        
        grid_sizer_param.Add(self.label_nomFichier, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        grid_sizer_param.Add(self.textctrl_nomFichier, 0, wx.ALL|wx.EXPAND, 0)
        
        grid_sizer_param.Add(self.label_elements, 0, wx.ALIGN_RIGHT, 0)
        grid_sizer_param.Add(self.treeCtrl, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_param.Add(self.label_destination, 0, wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 0)
        
        grid_sizer_destination = wx.FlexGridSizer(rows=1, cols=2, vgap=10, hgap=10)
        grid_sizer_destination.Add(self.textctrl_destination, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_destination.Add(self.bouton_destination, 0, wx.ALL|wx.EXPAND, 0)
        grid_sizer_destination.AddGrowableCol(0)
        grid_sizer_param.Add(grid_sizer_destination, 1, wx.EXPAND|wx.ALL, 0)

        staticbox.Add(grid_sizer_param, 1, wx.EXPAND|wx.ALL, 10)
        grid_sizer_base.Add(staticbox, 1, wx.ALL|wx.EXPAND, 10)
        
        grid_sizer_boutons.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_boutons.Add((20, 20), 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_annuler, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 10)
        
        sizer_base_2.Add(grid_sizer_base, 1, wx.EXPAND, 0)
        self.panel_base.SetSizer(sizer_base_2)
        sizer_base.Add(self.panel_base, 1, wx.EXPAND, 0)
        
        grid_sizer_base.AddGrowableRow(1)
        grid_sizer_base.AddGrowableCol(0)
        grid_sizer_param.AddGrowableCol(1)
        grid_sizer_param.AddGrowableRow(1)
        
        self.SetSizer(sizer_base)        
        sizer_base.Fit(self)
        self.Layout()
        self.SetMinSize((450, 320))
        self.SetSize((550, 400))
        self.CentreOnScreen()


    def OnBoutonDestination(self, event):
        if self.textctrl_destination.GetValue != "" : 
            cheminDefaut = self.textctrl_destination.GetValue()
            if os.path.isdir(cheminDefaut) == False :
                cheminDefaut = ""
        else:
            cheminDefaut = ""
        dlg = wx.DirDialog(self, _(u"Veuillez s�lectionner un r�pertoire de destination :"), defaultPath=cheminDefaut, style=wx.DD_DEFAULT_STYLE | wx.DD_DIR_MUST_EXIST)
        if dlg.ShowModal() == wx.ID_OK:
            self.textctrl_destination.SetValue(dlg.GetPath())
        dlg.Destroy()
        
        
    def OnClose(self, event):
        event.Skip()
        
    def OnBoutonAide(self, event):
        from Utils import UTILS_Aide
        UTILS_Aide.Aide("Creerunesauvegarde")

    def OnBoutonAnnuler(self, event):
        self.Destroy()

    def OnBoutonOk(self, event):
        """ Validation des donn�es saisies """
        
        # Nom du fichier
        varNomFichier = self.textctrl_nomFichier.GetValue()
        if varNomFichier == "" :
            dlg = wx.MessageDialog(self, _(u"Vous devez saisir un nom pour le fichier de sauvegarde !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # liste des �l�ments � sauver
        listeElements = self.treeCtrl.GetListeItemsCoches()
        if len(listeElements) == 0 :
            dlg = wx.MessageDialog(self, _(u"Vous devez s�lectionner au moins un �l�ment � sauvegarder dans la liste propos�e !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
            
        # Destination
        varDestination = self.textctrl_destination.GetValue()
        if varDestination == "" :
            dlg = wx.MessageDialog(self, _(u"Vous devez s�lectionner un r�pertoire de destination valide !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # Teste la validit� du r�pertoire
        if os.path.isdir(varDestination) == False :
            dlg = wx.MessageDialog(self, _(u"Le r�pertoire de destination s�lectionn� ne semble pas valide. Veuillez v�rifier votre saisie !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # Cr�ation de la sauvegarde occasionnelle :
        fichierDest = varDestination + "/" + varNomFichier + ".twz"
        
        # Le fichier de destination existe d�j� :
        if os.path.isfile(fichierDest) == True :
            dlg = wx.MessageDialog(None, _(u"Un fichier de sauvegarde portant ce nom existe d�j�. \n\nVoulez-vous le remplacer ?"), "Attention !", wx.YES_NO | wx.NO_DEFAULT | wx.ICON_EXCLAMATION)
            if dlg.ShowModal() == wx.ID_NO :
                return False
                dlg.Destroy()
            else:
                dlg.Destroy()
                    
        save = Sauvegarde()
        etat = save.Save(fichierDest, listeElements)
        if etat == None :
            # Sauvegarde r�ussie : Quitte
            dlg = wx.MessageDialog(self, _(u"La sauvegarde a �t� cr��e avec succ�s."), "Confirmation", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            self.Destroy()
        elif etat == False :
            # Sauvegarde non faite : Ne fait rien
            return
        else :
            # Message d'erreur
            dlg = wx.MessageDialog(self, _(u"L'erreur suivante s'est produit lors de la sauvegarde : \n\n") + err, "Erreur de sauvegarde", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return

        

# ------------------------------------------------------------------------------------------------------------------------------------------------------


class TreeCtrl_Sauvegarde(CT.CustomTreeCtrl):
    def __init__(self, parent, id=wx.ID_ANY, pos=wx.DefaultPosition, size=wx.DefaultSize, style=wx.SIMPLE_BORDER) :
        CT.CustomTreeCtrl.__init__(self, parent, id, pos, size, style)
        self.root = self.AddRoot("Sauvegarde")

        self.SetAGWWindowStyleFlag(wx.TR_HIDE_ROOT | wx.TR_HAS_BUTTONS | wx.TR_HAS_VARIABLE_ROW_HEIGHT | CT.TR_AUTO_CHECK_CHILD)
        self.EnableSelectionVista(True) 

        # Affiche les types de sources
        for typeSource, rep, extension in LISTE_SOURCES :
            item = self.AppendItem(self.root,  typeSource, ct_type=1)
            self.SetPyData(item, None)
            
            # Affiche les fichiers existants
            listeFichiers = os.listdir(rep)
            if len(listeFichiers) > 0 :
                nbreFichiers = 0
                for nomFichier in listeFichiers :
                    if nomFichier not in LISTE_INDESIRABLES :
                        child = self.AppendItem(item,  nomFichier, ct_type=1)
                        self.SetPyData(child, extension + "===" + rep + "===" + nomFichier)
                        nbreFichiers += 1
                
                if nbreFichiers > 0 :
                    self.CheckItem(item, checked=True)
                
            # D�roule l'item
            self.Expand(item)

    def GetListeItemsCoches(self):
        """ Obtient la liste des �l�ments coch�s """
        listeFichiers = []
        # Parcours les types de sources : (1�re branche)
        nbreTypeSources = self.GetChildrenCount(self.root)
        item = self.GetFirstChild(self.root)[0]
        for index in range(nbreTypeSources) :
            if self.IsItemChecked(item) and self.GetItemPyData(item) != None : 
                data = self.GetItemPyData(item).split("===")
                listeFichiers.append(data)
            item = self.GetNext(item)
            
        return listeFichiers
           
            

# ------------------------------------------------------------------------------------------------------------------------------------------------

class Sauvegarde_auto():
    """ Sauvegardes automatiques � la fermeture du logiciel """
    def Save(self):
        
        nomFichierDest = "SaveAuto"
        
        # Recherche dans la base des param�tres de la sauvegarde auto.
        DB = GestionDB.DB()        
        req = "SELECT save_active, save_frequence, save_elements, save_destination, save_conservation, save_date_derniere FROM divers WHERE IDdivers=1;"
        DB.ExecuterReq(req)
        donnees = DB.ResultatReq()
        DB.Close()
        if len(donnees) == 0 : return False
        self.activation = donnees[0][0]
        self.frequence = donnees[0][1]
        self.elements = donnees[0][2]
        self.destination = donnees[0][3]
        self.conservation = donnees[0][4]
        self.dateDerniere = donnees[0][5]
        
        # V�rifie que la sauvegarde auto est activ�e :
        if self.activation == 0 : 
            return False
        
        # V�rifie que la fr�quence impose une sauvegarde aujourd'hui :
        if self.frequence != 0 : 
            if self.dateDerniere != "" and self.dateDerniere != None :
                date_derniere = datetime.date( int(self.dateDerniere[:4]), int(self.dateDerniere[5:7]), int(self.dateDerniere[8:10]))
                date_jour =  datetime.date.today()
                nbreJours = (date_jour-date_derniere).days
                # Toutes les semaines
                if self.frequence == 1 and nbreJours < 7 : return False
                 # Tous les 15 jours
                if self.frequence == 2 and nbreJours < 15 : return False
                 # Tous les mois
                if self.frequence == 3 and nbreJours < 30 : return False
        
        # On v�rifie que le r�pertoire de destination existe bien
        if os.path.isdir(self.destination) == False :
            print("Le repertoire de destination de sauvegarde auto n'existe pas.")
            return False
            
        # V�rifie que la conservation n'impose pas la suppression d'un vieux fichier de sauvegarde
        if self.conservation > 0 :
            # On recherche les fichiers d�j� pr�sents dans le r�pertoire :
            listeFichierExistants = []
            contenuRepertoire = os.listdir(self.destination)
            for fichier in contenuRepertoire :
                if fichier.startswith(nomFichierDest) and fichier.endswith(".twz"):
                    listeFichierExistants.append(fichier)
        
            # On trie la liste du plus ancien au plus r�cent :
            listeFichierExistants.sort()
            
            # On supprime les plus anciens
            if len(listeFichierExistants) > self.conservation :
                for fichier in listeFichierExistants[:len(listeFichierExistants) - self.conservation] :
                    os.remove(self.destination + "/" + fichier)
        
        # Cr�ation de la liste des fichiers � sauvegarder :
        listeElements = self.elements.split(";")
        if len(listeElements) == 0 : return False
        listeFichiers = []
        for typeSource, rep, extension in LISTE_SOURCES :
            if extension in listeElements :
                fichiersRep = os.listdir(rep)
                for nomFichier in fichiersRep :
                    if nomFichier not in LISTE_INDESIRABLES :
                        listeFichiers.append( (extension, rep, nomFichier) )
        
        if len(listeFichiers) == 0 : # Aucun fichier � sauvegarder
            return False
        
        # Cr�ation de la sauvegarde
        fichierDest = self.destination + "/" + nomFichierDest + "_" + str(datetime.date.today()) + ".twz"
        save = Sauvegarde()
        etat = save.Save(fichierDest, listeFichiers)
        
        if etat == None :
            # Sauvegarde r�ussie : Quitte
            return
        elif etat == False :
            # Sauvegarde non faite : Ne fait rien
            return
        else :
            # Message d'erreur
            dlg = wx.MessageDialog(None, _(u"L'erreur suivante s'est produit lors de la sauvegarde : \n\n") + etat, "Erreur de sauvegarde", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
            


# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class Restauration(wx.Frame):
    def __init__(self, parent, fichierRestauration=""):
        wx.Frame.__init__(self, parent, -1, title="", style=wx.DEFAULT_FRAME_STYLE)
        self.fichierRestauration = fichierRestauration
        self.panel_base = wx.Panel(self, -1)
        texteIntro = _(u"Veuillez s�lectionner les �l�ments � restaurer :")
        self.label_introduction = FonctionsPerso.StaticWrapText(self.panel_base, -1, texteIntro)
        self.treeCtrl = TreeCtrl_Restauration(self.panel_base, fichierRestauration, -1)         
        self.bouton_aide = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Aide"), cheminImage=Chemins.GetStaticPath("Images/32x32/Aide.png"))
        self.bouton_ok = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Ok"), cheminImage=Chemins.GetStaticPath("Images/32x32/Valider.png"))
        self.bouton_annuler = CTRL_Bouton_image.CTRL(self.panel_base, texte=_(u"Annuler"), cheminImage=Chemins.GetStaticPath("Images/32x32/Annuler.png"))

        self.__set_properties()
        self.__do_layout()

        self.Bind(wx.EVT_BUTTON, self.OnBoutonAide, self.bouton_aide)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonOk, self.bouton_ok)
        self.Bind(wx.EVT_BUTTON, self.OnBoutonAnnuler, self.bouton_annuler)
        self.Bind(wx.EVT_CLOSE, self.OnClose)

        
    def __set_properties(self):
        if 'phoenix' in wx.PlatformInfo:
            _icon = wx.Icon()
        else :
            _icon = wx.EmptyIcon()
        _icon.CopyFromBitmap(wx.Bitmap(Chemins.GetStaticPath("Images/16x16/Restaurer.png"), wx.BITMAP_TYPE_ANY))
        self.SetIcon(_icon)
        self.SetTitle(_(u"Restauration d'une sauvegarde"))
        self.bouton_aide.SetToolTip(wx.ToolTip("Cliquez ici pour obtenir de l'aide"))
        self.bouton_aide.SetSize(self.bouton_aide.GetBestSize())
        self.bouton_ok.SetToolTip(wx.ToolTip("Cliquez ici pour valider"))
        self.bouton_ok.SetSize(self.bouton_ok.GetBestSize())
        self.bouton_annuler.SetToolTip(wx.ToolTip("Cliquez ici pour annuler la saisie"))
        self.bouton_annuler.SetSize(self.bouton_annuler.GetBestSize())

    def __do_layout(self):
        sizer_base = wx.BoxSizer(wx.VERTICAL)
        sizer_base_2 = wx.BoxSizer(wx.VERTICAL)
        grid_sizer_base = wx.FlexGridSizer(rows=2, cols=1, vgap=0, hgap=0)
        grid_sizer_boutons = wx.FlexGridSizer(rows=1, cols=4, vgap=10, hgap=10)
        grid_sizer_base.Add(self.label_introduction, 1, wx.ALL|wx.EXPAND, 10)
        grid_sizer_base.Add(self.treeCtrl, 1, wx.ALL|wx.EXPAND, 10)
        
        grid_sizer_boutons.Add(self.bouton_aide, 0, 0, 0)
        grid_sizer_boutons.Add((20, 20), 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_ok, 0, 0, 0)
        grid_sizer_boutons.Add(self.bouton_annuler, 0, 0, 0)
        grid_sizer_boutons.AddGrowableCol(1)
        grid_sizer_base.Add(grid_sizer_boutons, 1, wx.LEFT|wx.RIGHT|wx.BOTTOM|wx.EXPAND, 10)
        
        sizer_base_2.Add(grid_sizer_base, 1, wx.EXPAND, 0)
        self.panel_base.SetSizer(sizer_base_2)
        sizer_base.Add(self.panel_base, 1, wx.EXPAND, 0)
        
        grid_sizer_base.AddGrowableRow(1)
        grid_sizer_base.AddGrowableCol(0)
        
        self.SetSizer(sizer_base)        
        sizer_base.Fit(self)
        self.Layout()
        self.SetMinSize((450, 320))
        self.SetSize((550, 400))
        self.CentreOnScreen()
        
        
    def OnClose(self, event):
        event.Skip()
        
    def OnBoutonAide(self, event):
        from Utils import UTILS_Aide
        UTILS_Aide.Aide("Restaurerunesauvegarde")

    def OnBoutonAnnuler(self, event):
        self.Destroy()

    def OnBoutonOk(self, event):
        """ Validation des donn�es saisies """
        
        # liste des �l�ments � sauver
        listeFichiers = self.treeCtrl.GetListeItemsCoches()
        if len(listeFichiers) == 0 :
            dlg = wx.MessageDialog(self, _(u"Vous devez s�lectionner au moins un �l�ment � restaurer dans la liste propos�e !"), "Erreur", wx.OK)  
            dlg.ShowModal()
            dlg.Destroy()
            return
        
        # Lance la restauration
        self.Resto(listeFichiers)
    
    def Resto(self, listeFichiers=[]):
        # Cr��e un dictionnaire des r�pertoires :
        dictChemins = {}
        for nomSource, rep, ext in LISTE_SOURCES :
            dictChemins[ext] = rep

        # Ouverture du fichier ZIP
        fichierZip = zipfile.ZipFile(self.fichierRestauration, "r")
        
        for fichier in listeFichiers :
            extensionFichier = fichier[:4]
            nomFichier = fichier[5:]
            chemin = dictChemins[extensionFichier]
            
            # On v�rifie que le fichier n'existe pas d�j� dans le r�pertoire de destination
            if os.path.isfile(chemin + nomFichier) == True :
                dlg = wx.MessageDialog(None, _(u"Le fichier '") + nomFichier.decode("iso-8859-15") + _(u"' existe d�j�. \n\nVoulez-vous le remplacer ?"), "Attention !", wx.YES_NO | wx.CANCEL |wx.NO_DEFAULT | wx.ICON_EXCLAMATION)
                reponse = dlg.ShowModal()
                dlg.Destroy()
                if reponse == wx.ID_NO :
                    validation = False                    
                elif reponse == wx.ID_YES :
                    validation = True
                else :
                    validation = "stop"
                    dlg2 = wx.MessageDialog(self, _(u"Restauration arr�t�e."), _(u"Restauration arr�t�e"), wx.OK| wx.ICON_INFORMATION)  
                    dlg2.ShowModal()
                    dlg2.Destroy()
                    fichierZip.close()
                    return
            else:
                validation = True               
            
            # On restaure le fichier
            if validation == True :
                try :
                    buffer = fichierZip.read(fichier)
                    f = open (chemin + nomFichier, "wb")
                    f.write(buffer)
                    f.close()
                except err :
                    dlg = wx.MessageDialog(self, _(u"La restauration du fichier '") + nomFichier + _(u"' a rencontr� l'erreur suivante : \n") + err, "Erreur", wx.OK| wx.ICON_ERROR)  
                    dlg.ShowModal()
                    dlg.Destroy()
            
        fichierZip.close()
        
        # Message de confirmation de r�ussite
        dlg = wx.MessageDialog(self, _(u"Vos fichiers ont �t� restaur�s avec succ�s."), _(u"Restauration r�ussie"), wx.OK| wx.ICON_INFORMATION)  
        dlg.ShowModal()
        dlg.Destroy()
        
        # Fermeture de la fen�tre
        self.Destroy()
        

# ------------------------------------------------------------------------------------------------------------------------------------------------------

class TreeCtrl_Restauration(CT.CustomTreeCtrl):
    def __init__(self, parent, fichier="", id=wx.ID_ANY, pos=wx.DefaultPosition, size=wx.DefaultSize, style=wx.SIMPLE_BORDER) :
        CT.CustomTreeCtrl.__init__(self, parent, id, pos, size, style)
        self.root = self.AddRoot("Restauration")

        self.SetAGWWindowStyleFlag(wx.TR_HIDE_ROOT | wx.TR_HAS_BUTTONS | wx.TR_HAS_VARIABLE_ROW_HEIGHT | CT.TR_AUTO_CHECK_CHILD)
        self.EnableSelectionVista(True) 

        # Ouverture du fichier ZIP
        fichierZip = zipfile.ZipFile(fichier, "r")
            
        # Recherche les types de sources pr�sents dans la sauvegarde
        listeTypesSources = {}
        for fichier in fichierZip.namelist() :
            extensionFichier = fichier[:4]
            listeTypesSources[extensionFichier] = ""
        
        # Affiche les types de sources
        for typeSource, rep, extensionSource in LISTE_SOURCES :
            if (extensionSource in listeTypesSources) == True :
                item = self.AppendItem(self.root,  typeSource, ct_type=1)
                self.SetPyData(item, None)
                
                # Affiche les fichiers existants
                for fichier in fichierZip.namelist() :
                    extensionFichier = fichier[:4]
                    nomFichier = fichier[5:]
                    if extensionFichier == extensionSource :
                        child = self.AppendItem(item,  nomFichier, ct_type=1)
                        self.SetPyData(child, fichier)
                    self.CheckItem(item, checked=True)
                    
                # D�roule l'item
                self.Expand(item)
        
        fichierZip.close()

    def GetListeItemsCoches(self):
        """ Obtient la liste des �l�ments coch�s """
        listeFichiers = []
        # Parcours les types de sources : 
        nbreTypeSources = self.GetChildrenCount(self.root)
        item = self.GetFirstChild(self.root)[0]
        for index in range(nbreTypeSources) :
            if self.IsItemChecked(item) and self.GetItemPyData(item) != None : 
                data = self.GetItemPyData(item)
                listeFichiers.append(data)
            item = self.GetNext(item)
            
        return listeFichiers
           
            

# ------------------------------------------------------------------------------------------------------------------------------------------------



if __name__ == "__main__":
    app = wx.App(0)
    #wx.InitAllImageHandlers()
    frame_1 = MyFrame(None, "")
    app.SetTopWindow(frame_1)
    frame_1.Show()
    app.MainLoop()
